﻿namespace P013WebSite.Models
{
    public class UrunDto
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string? Image { get; set; }
    }
}
